# Meal Rotation Planner — standalone website

This is the same meal and nutrition tracker, built to run as its own website instead of
inside claude.ai. It needs no Claude account, no sign-in, and no server: every file here
is static, and each person's data stays in their own browser.

## Why this exists

The version shared through a claude.ai link runs inside a sandboxed frame that Anthropic
uses for all published artifacts. Browser storage does not reliably work inside that frame,
so a shared claude.ai link can look fine in the moment and then lose everything the next
time someone opens it. This standalone build has no such sandbox: I tested it with a real
browser and confirmed saving, closing, and reopening all work normally. It also adds a
built-in check that warns a person immediately if their own browser's storage is somehow
not working, instead of failing silently.

What is different from the claude.ai version:
- No AI tab and no photo label reader — those need a live claude.ai connection, so that tab
  is hidden here entirely. Labels are typed in on the Scan tab instead.
- No sync between a person's own devices. Each device holds its own data. Moving data
  between devices, or keeping a safety copy, is done with the "Download a backup" and
  "Restore from a backup" buttons under "Help and backup".
- The barcode list (`products.json`) is its own file, so it can be refreshed without
  touching the app itself.
- It can be installed to a phone's home screen and works offline after the first visit.

## What changed in 2026.09.22-1

Five ways to log a food faster:
- **Recent foods** and **pinned staples**: one-tap chips above the food search box.
- **Log again**: a button on any Day-tab entry to log a second helping instantly.
- **One-tap barcode**: an opt-in Scan-tab setting that logs a known barcode the moment it scans.
- **Copy a day onto today**: pull any past day's meals onto today in one action.

If you are updating an existing deployment, upload the new `index.html`, `products.json`
(unchanged this time), and `version.json` from this `site` folder. People already using
the site will see an "a newer version is available" banner within about 30 minutes, or the
next time they open it.

## What changed in 2026.09.23-1

The "Barcodes the app already recognizes" list on the Scan tab (the small arrow to expand
it) now shows each brand's name clearly first, then what it covers, then the barcode count
in parentheses -- instead of a single run-on line cramming counts and descriptions together.

If you are updating an existing deployment, upload the new `index.html` and `version.json`
from this `site` folder. `products.json` did not change. People already using the site will
see an "a newer version is available" banner within about 30 minutes, or the next time they
open it.

## What changed in 2026.09.23-2

The quick-add foods above the search box on the Day tab now work per meal slot, and favor
foods you have actually scanned or entered yourself:

- A food you scanned or typed in shows up as a one-tap button the moment you have logged it
  once for a given meal -- breakfast, lunch, dinner, or snacks.
- A generic USDA food only joins that list once it is genuinely a habit for that particular
  slot (logged a couple of times recently, or more further back). One try does not count.
- Breakfast, lunch, dinner, and snack suggestions are now kept fully separate: a dinner
  favorite never shows up while you are adding breakfast, and the other way around.
- The separate "your most-used foods" row (which ignored which meal it was for) has been
  folded into this one, slot-aware row, so there is one row doing this job, not two.

If you are updating an existing deployment, upload the new `index.html` and `version.json`
from this `site` folder. `products.json` did not change.

## What changed in 2026.09.23-3

Correcting the previous update: lunch and dinner now share one pool of quick-add foods
(logging something at lunch makes it available as a one-tap suggestion at dinner too, and
the other way around), since people often eat the same things at either. Breakfast and
snacks each still keep their own separate pool, untouched by this change.

If you are updating an existing deployment, upload the new `index.html` and `version.json`
from this `site` folder. `products.json` did not change.

## What changed in 2026.09.23-4

Fixing a real problem from the previous update: foods you actually eat often could vanish
from the quick-add row entirely if they hadn't crossed an arbitrary "used twice recently"
bar, especially with only a short history so far. That hard cutoff is gone. Now nothing is
ever hidden outright: any food you have logged in a slot shows up, your own scanned or
typed-in foods just start ranked a little higher than an equally-used generic food, and a
food you genuinely eat often naturally rises to the top over time.

If you are updating an existing deployment, upload the new `index.html` and `version.json`
from this `site` folder. `products.json` did not change.

## What changed in 2026.09.23-5

Extended the lunch/dinner merge to the "Add a meal" dropdown and its one-tap chips, not just
the individual-food quick-add row. A meal you eat at lunch now shows under "Usual for lunch
and dinner" when adding to either slot, and the same for a dinner meal. Breakfast keeps its
own separate list, untouched.

If you are updating an existing deployment, upload the new `index.html` and `version.json`
from this `site` folder. `products.json` did not change.

## What changed in 2026.09.23-6

Fixed a real bug: any meal you had saved but never actually planned onto a day (a recipe
you created but hadn't logged yet) was being shown as "usual" for every single meal slot,
including breakfast -- so dinner dishes like pasta or salmon could appear in the breakfast
suggestions. That fallback is gone. "Usual for X" now only ever shows meals you have
actually eaten at that time before. A never-planned meal still shows up fine under "More
meals", it just is not falsely presented as a habit it is not yet.

If you are updating an existing deployment, upload the new `index.html` and `version.json`
from this `site` folder. `products.json` did not change.

## What changed in 2026.09.30-1

The RDI tab (Vitamins and minerals) can now average a week instead of just showing one day:
- A **Day / Week average** toggle at the top of the RDI tab. Week average shows the per-day
  average across whichever of the last 7 days actually have anything logged (empty days do
  not drag the average down), the same way the Week tab already averages calories.
- Underneath the amounts, a **"To add next week"** list ranks every nutrient that is
  under its goal on average, lowest first, and a **"To cut back next week"** list does the
  same for sodium (or anything over its upper limit) — a direct answer to "what should I
  change or add next week."
- Also restored 4 verified-label products (Coconutmilk Beverage Unsweetened, Country Crock
  Original Spread, Caesar Dressing, Pistachios No Shells Roasted Unsalted) that had been
  added straight to a previous deployment's `products.json` but were missing from the app's
  own master copy, so a future rebuild would have silently dropped them. The barcode list is
  back to 766 products.

If you are updating an existing deployment, upload the new `index.html`, `products.json`,
and `version.json` from this `site` folder.

## What changed in 2026.09.30-2

Removed the sous vide cook planner. On this standalone site it was the only thing shown on
the "AI" tab (since the real AI helpers need a live claude.ai connection), so that tab is
now hidden here entirely rather than shown empty. On the claude.ai version, the AI tab keeps
its other 6 tools (Describe a meal, Ingredient ideas, Fill the day, Swap a meal, Review my
plan, Shopping list) unchanged. No data is affected: any device that had sous vide settings
or added sous vide foods saved from before just quietly stops syncing them.

If you are updating an existing deployment, upload the new `index.html` and `version.json`
from this `site` folder. `products.json` did not change.

## What changed in 2026.10.01-1

Faster ways to log food without searching and tapping "add" one item at a time, and a way
for whoever maintains this site to find out which foods are missing from it:

- **Add several foods at once**: a "+ Add several at once" button on each meal (Day tab)
  opens a box where you list what you ate, one food per line, and it matches and logs all
  of them in one go.
- **Bulk barcode scanning**: with "Log a known barcode the instant it scans" turned on, the
  live camera now keeps scanning after each one instead of stopping — several barcodes in a
  row log automatically, one after another. An unrecognized barcode no longer interrupts the
  run with a form; it is simply noted for later.
- **Paste a batch of barcode numbers**: a "+ Add several barcodes at once" box on the Scan
  tab, for anyone who already has a list of numbers (from a barcode-scanning phone app, a
  dedicated Bluetooth scanner, or typed from receipts) and would rather paste them than scan
  one at a time. A Bluetooth barcode scanner also now works directly with the existing
  "type the number" box — it types the digits and presses Enter for you.
- **Export foods needing database entries**: anything typed or scanned that matched nothing
  is never silently dropped. It is noted, and a new "Foods not found" section on the Help
  screen lets you export that list (just names and numbers, nothing personal) to send to
  whoever maintains this app's food list.

If you are updating an existing deployment, upload the new `index.html` and `version.json`
from this `site` folder. `products.json` did not change.

## What changed in 2026.10.01-2

Four products added to the barcode list, verified from a real "Foods not found" export sent
in from a phone testing the site:
- Nature's Path Love Crunch Organic Dark Chocolate & Blueberry Granola
- Epic Bison Bar, Uncured Bacon + Cranberry
- Pretzelized Snacks Honey Mustard Pretzel Crackers
- Laird Superfood Vanilla Liquid Creamer

The barcode list is now 770 products.

If you are updating an existing deployment, upload the new `index.html`, `products.json`,
and `version.json` from this `site` folder.

## What changed in 2026.10.01-3

Sending the "Foods not found" list is now one tap, from right next to "Help and backup":

- A **"Send N unmatched"** shortcut appears at the top of the app, beside "Help and backup",
  whenever there is something to send — no need to open Help first.
- On a phone, tapping it (either there or the button inside Help) now opens your normal
  share sheet (Messages, Mail, AirDrop, whatever you have) with the file already attached,
  so you can hand it straight to whoever maintains this app's food list. Where sharing a
  file is not available, it falls back to an ordinary download, as before.

If you are updating an existing deployment, upload the new `index.html` and `version.json`
from this `site` folder. `products.json` did not change.

## What changed in 2026.10.02-1

Fixed a real bug: with "Log a known barcode the instant it scans" turned on, the live
camera used to visibly flicker on every single scan. It was fully releasing the camera and
asking for a brand new one each time to keep going, instead of just carrying on with the one
already open. It now keeps the same camera stream open the whole time you are scanning in a
row (the camera opens once and stays on), so a run of barcodes -- 5, 20, however many -- goes
smoothly with no flicker. It still closes normally when you tap Cancel or back out.

If you are updating an existing deployment, upload the new `index.html` and `version.json`
from this `site` folder. `products.json` did not change.

## What changed in 2026.10.02-2

A speed tweak for scanning on phones without a fast built-in barcode reader (notably
iPhone, where Safari has none at all -- Chrome on Android usually does): the live camera
used to require reading the exact same barcode twice in a row before accepting it. That
extra confirmation frame added real waiting time on a phone that is already decoding each
frame slowly, for not much real safety -- the barcode's own built-in check digit, verified
right after, already catches a garbled read far more reliably. It now accepts a barcode as
soon as it reads cleanly once. (I could not test this against a real iPhone camera myself,
since I don't have access to one -- if scanning still feels slow after this, or you start
seeing a wrong product come up, let me know and we can look at a bigger change: swapping in
a dedicated barcode-reading library in place of this app's own decoder.)

If you are updating an existing deployment, upload the new `index.html` and `version.json`
from this `site` folder. `products.json` did not change.

## What changed in 2026.10.02-3

The "Foods not found" list (barcodes and names the app couldn't match) used to just sit
there after you exported or shared it -- nothing in the app itself showed that the send had
actually happened, so there was no way to tell a successful send from one that silently
failed. Now, the moment a send genuinely goes through -- the file actually downloads, or the
share sheet is actually used, not cancelled -- that list clears itself, with a few seconds to
tap "Undo" right on the confirmation toast in case that was a mistake. A future count only
ever shows what's new since the last time you actually sent it. The "Send N unmatched"
shortcut next to Help and backup disappears too once its list is empty. Help's explanation of
this screen was updated to match.

If you are updating an existing deployment, upload the new `index.html` and `version.json`
from this `site` folder. `products.json` did not change.

## Deploying it (you do this part; I cannot host anything myself)

Any static host that serves plain files over HTTPS will do. The simplest is GitHub Pages:

1. Create a GitHub repository (or use an existing one).
2. Upload every file in this folder (`index.html`, `products.json`, `manifest.webmanifest`,
   `sw.js`, `version.json`, and the icon files) to the repository, keeping them all in the
   same folder — do not put them in subfolders.
3. In the repository's Settings, open "Pages", and set it to serve from that branch and folder.
4. GitHub gives you a URL such as `https://yourname.github.io/your-repo/`. That is the link
   to share. It can take a few minutes to go live the first time.
5. Open the link yourself first, on both a computer and a phone, before sharing it further.

Netlify and Cloudflare Pages both also accept a folder of files dropped in directly, if you
would rather not use GitHub.

Do not let any AI website-builder "fix" or rewrite these files before deploying — this
copy has already been tested as it is, and rewriting it can silently reintroduce the very
problems it was built to avoid.

## Updating it later

When I give you a new version of the app:
1. Ask me for an updated `index.html` (and `products.json`, if the product list changed).
2. Also update `version.json` to a new version number — this is what makes the "a newer
   version is available" banner appear for people already using the site.
3. Upload the changed files to the same place. Nobody needs to do anything else; the site
   checks `version.json` for them and offers the update.

## Refreshing the product list only

The barcode list lives entirely in `products.json`. To rebuild it from a fresh USDA
FoodData Central download without touching the app itself, see `dev/tools/make_products.py`
in the developer bundle. Send me the new USDA zip file and I can run it for you and hand
back an updated `products.json` and `version.json`.

## If something breaks for someone

Ask them to open "Help and backup" (under the title) and tap "Copy support info", then send
you that text. It has their browser, screen, whether saving actually works, and version
and product-list numbers — never their meals, weights, or other personal details. Send it
to me and I will diagnose it from that.

## What I have not been able to test

I have tested this in a real desktop browser, including offline mode, installing, and a
simulated broken-storage browser. I have not been able to test it on an actual iPhone,
in Safari, or in any other real mobile browser. Please test it yourselves on real phones
before sharing it widely, especially the "add to home screen" and offline behavior.
